# script_estatistica.py

from collections import Counter

def calcular_media(lista):
    return sum(lista) / len(lista)

def calcular_mediana(lista):
    lista_ordenada = sorted(lista)
    n = len(lista_ordenada)
    
    if n % 2 == 1:
        return lista_ordenada[n // 2]
    else:
        meio1 = lista_ordenada[n // 2 - 1]
        meio2 = lista_ordenada[n // 2]
        return (meio1 + meio2) / 2

def calcular_moda(lista):
    frequencia = Counter(lista)
    max_freq = max(frequencia.values())
    
    modas = [num for num, freq in frequencia.items() if freq == max_freq]
    
    if max_freq == 1:
        return "Amodal (não há moda)"
    elif len(modas) == 1:
        return modas[0]
    else:
        return f"Bimodal/Multimodal: {modas}"

def main():
    print("📊 Cálculo de Média, Mediana e Moda")
    
    entrada = input("Digite os números separados por espaço: ")
    
    try:
        lista = list(map(float, entrada.split()))
        
        media = calcular_media(lista)
        mediana = calcular_mediana(lista)
        moda = calcular_moda(lista)
        
        print("\nResultados:")
        print(f"Média: {media}")
        print(f"Mediana: {mediana}")
        print(f"Moda: {moda}")
    
    except:
        print("❌ Erro: Certifique-se de digitar apenas números.")

if __name__ == "__main__":
    main()