# regressao_com_outliers.py

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# -------------------------------
# 1. Gerando dados "normais"
# -------------------------------
np.random.seed(42)

x = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
y = np.array([2, 4, 5, 4, 5, 7, 8, 9, 10, 12])

# -------------------------------
# 2. Adicionando outliers
# -------------------------------
x_outliers = np.array([3, 8, 10]).reshape(-1, 1)
y_outliers = np.array([15, 1, 20])

# Juntando tudo
x_total = np.vstack((x, x_outliers))
y_total = np.concatenate((y, y_outliers))

# -------------------------------
# 3. Modelo sem outliers
# -------------------------------
modelo_sem_outliers = LinearRegression()
modelo_sem_outliers.fit(x, y)
y_pred_sem = modelo_sem_outliers.predict(x)

# -------------------------------
# 4. Modelo com outliers
# -------------------------------
modelo_com_outliers = LinearRegression()
modelo_com_outliers.fit(x_total, y_total)
y_pred_com = modelo_com_outliers.predict(x_total)

# -------------------------------
# 5. Exibindo coeficientes
# -------------------------------
print("=== REGRESSÃO SEM OUTLIERS ===")
print(f"Coeficiente angular (slope): {modelo_sem_outliers.coef_[0]:.4f}")
print(f"Intercepto: {modelo_sem_outliers.intercept_:.4f}")

print("\n=== REGRESSÃO COM OUTLIERS ===")
print(f"Coeficiente angular (slope): {modelo_com_outliers.coef_[0]:.4f}")
print(f"Intercepto: {modelo_com_outliers.intercept_:.4f}")

# -------------------------------
# 6. Gráfico
# -------------------------------
plt.figure(figsize=(10, 6))

# Dados normais
plt.scatter(x, y, label="Dados normais", s=80)

# Outliers
plt.scatter(x_outliers, y_outliers, label="Outliers", s=100, marker="x")

# Reta sem outliers
plt.plot(x, y_pred_sem, label="Regressão sem outliers", linewidth=2)

# Para desenhar a reta com outliers de forma ordenada
x_linha = np.linspace(min(x_total), max(x_total), 100).reshape(-1, 1)
y_linha_com = modelo_com_outliers.predict(x_linha)
plt.plot(x_linha, y_linha_com, label="Regressão com outliers", linewidth=2)

plt.title("Regressão Linear com Outliers")
plt.xlabel("Variável X")
plt.ylabel("Variável Y")
plt.legend()
plt.grid(True)
plt.show()