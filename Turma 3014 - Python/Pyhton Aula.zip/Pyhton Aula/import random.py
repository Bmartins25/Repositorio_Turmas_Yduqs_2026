import random

# cria individuo
def criar_individuo(tamanho):
    return [random.randint(0,1) for _ in range(tamanho)]

# fitness = soma dos bits
def fitness(individuo):
    return sum(individuo)

# seleção simples (melhores)
def selecionar(populacao):
    return sorted(populacao, key=fitness, reverse=True)[:2]

# crossover
def crossover(pai1, pai2):
    ponto = len(pai1)//2
    return pai1[:ponto] + pai2[ponto:]

# mutação
def mutacao(individuo):
    i = random.randint(0, len(individuo)-1)
    individuo[i] = 1 - individuo[i]
    return individuo

# algoritmo genetico
def algoritmo_genetico():
    populacao = [criar_individuo(5) for _ in range(6)]

    for geracao in range(10):
        melhores = selecionar(populacao)

        nova_pop = melhores.copy()

        while len(nova_pop) < 6:
            filho = crossover(melhores[0], melhores[1])
            if random.random() < 0.1:
                filho = mutacao(filho)
            nova_pop.append(filho)

        populacao = nova_pop

        print(f"Geração {geracao}: {populacao}")

algoritmo_genetico()