# heatmap_correlacao.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def gerar_dados_exemplo():
    np.random.seed(42)
    
    dados = {
        "Vendas": np.random.randint(100, 500, 50),
        "Marketing": np.random.randint(50, 300, 50),
        "Clientes": np.random.randint(20, 200, 50),
        "Satisfacao": np.random.randint(1, 10, 50),
        "Tempo_Site": np.random.randint(1, 60, 50)
    }
    
    return pd.DataFrame(dados)

def main():
    print("📊 Mapa de Calor de Correlação")

    opcao = input("Deseja usar dados simulados? (s/n): ").lower()

    if opcao == 's':
        df = gerar_dados_exemplo()
    else:
        caminho = input("Digite o caminho do arquivo CSV: ")
        try:
            df = pd.read_csv(caminho)
        except:
            print("❌ Erro ao carregar o arquivo.")
            return

    print("\n📌 Dados carregados:")
    print(df.head())

    # -------------------------------
    # Correlação
    # -------------------------------
    correlacao = df.corr(numeric_only=True)

    print("\n📌 Matriz de Correlação:")
    print(correlacao)

    # -------------------------------
    # Heatmap
    # -------------------------------
    plt.figure(figsize=(8, 6))
    plt.imshow(correlacao)

    plt.xticks(range(len(correlacao.columns)), correlacao.columns, rotation=45)
    plt.yticks(range(len(correlacao.columns)), correlacao.columns)

    # Adicionando valores nas células
    for i in range(len(correlacao.columns)):
        for j in range(len(correlacao.columns)):
            plt.text(j, i, f"{correlacao.iloc[i, j]:.2f}",
                     ha="center", va="center")

    plt.title("Mapa de Calor - Correlação entre Variáveis")
    plt.colorbar()
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()