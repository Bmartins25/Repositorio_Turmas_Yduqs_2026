# ============================================================
# AULA DE INTELIGÊNCIA ARTIFICIAL COM PYSPARK
# Exemplo: prever aprovação de alunos
# ============================================================

# ------------------------------------------------------------
# 1. Importações
# ------------------------------------------------------------
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# ------------------------------------------------------------
# 2. Criando a sessão Spark
# ------------------------------------------------------------
spark = SparkSession.builder \
    .appName("Aula_IA_PySpark") \
    .getOrCreate()

# ------------------------------------------------------------
# 3. Criando os dados de exemplo
# ------------------------------------------------------------
dados = [
    (2, 8, 5.0, "Reprovado"),
    (3, 6, 5.5, "Reprovado"),
    (5, 2, 7.0, "Aprovado"),
    (7, 1, 8.5, "Aprovado"),
    (1, 10, 4.0, "Reprovado"),
    (4, 5, 6.0, "Reprovado"),
    (6, 2, 7.5, "Aprovado"),
    (8, 0, 9.0, "Aprovado"),
    (3, 7, 5.2, "Reprovado"),
    (6, 1, 8.0, "Aprovado"),
    (5, 3, 6.8, "Aprovado"),
    (2, 9, 4.8, "Reprovado")
]

colunas = ["horas_estudo", "faltas", "nota_inicial", "resultado"]

df = spark.createDataFrame(dados, colunas)

print("=== Base de dados ===")
df.show()

print("=== Esquema dos dados ===")
df.printSchema()

# ------------------------------------------------------------
# 4. Transformando a variável alvo em número
# ------------------------------------------------------------
indexador = StringIndexer(inputCol="resultado", outputCol="label")

# ------------------------------------------------------------
# 5. Montando o vetor de características
# ------------------------------------------------------------
assembler = VectorAssembler(
    inputCols=["horas_estudo", "faltas", "nota_inicial"],
    outputCol="features"
)

# ------------------------------------------------------------
# 6. Criando o modelo
# ------------------------------------------------------------
modelo_dt = DecisionTreeClassifier(
    featuresCol="features",
    labelCol="label",
    predictionCol="prediction"
)

# ------------------------------------------------------------
# 7. Criando o pipeline
# ------------------------------------------------------------
pipeline = Pipeline(stages=[indexador, assembler, modelo_dt])

# ------------------------------------------------------------
# 8. Separando treino e teste
# ------------------------------------------------------------
treino, teste = df.randomSplit([0.8, 0.2], seed=42)

print("Quantidade de registros de treino:", treino.count())
print("Quantidade de registros de teste:", teste.count())

# ------------------------------------------------------------
# 9. Treinando o modelo
# ------------------------------------------------------------
modelo_treinado = pipeline.fit(treino)

# ------------------------------------------------------------
# 10. Fazendo previsões
# ------------------------------------------------------------
previsoes = modelo_treinado.transform(teste)

print("=== Previsões no conjunto de teste ===")
previsoes.select(
    "horas_estudo",
    "faltas",
    "nota_inicial",
    "resultado",
    "prediction"
).show()

# ------------------------------------------------------------
# 11. Avaliando o modelo
# ------------------------------------------------------------
avaliador = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="accuracy"
)

acuracia = avaliador.evaluate(previsoes)
print(f"Acurácia do modelo: {acuracia:.2f}")

# ------------------------------------------------------------
# 12. Testando novos alunos
# ------------------------------------------------------------
novos_dados = [
    (4, 3, 6.5),
    (2, 8, 5.0),
    (7, 1, 8.2),
    (5, 4, 6.9)
]

novos_colunas = ["horas_estudo", "faltas", "nota_inicial"]
novos_alunos = spark.createDataFrame(novos_dados, novos_colunas)

print("=== Novos alunos ===")
novos_alunos.show()

novas_previsoes = modelo_treinado.transform(novos_alunos)

print("=== Resultado previsto pela IA ===")
novas_previsoes.select(
    "horas_estudo",
    "faltas",
    "nota_inicial",
    "prediction"
).show()

# ------------------------------------------------------------
# 13. Encerrando sessão Spark
# ------------------------------------------------------------
spark.stop()