from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
import pandas as pd

# ==================================================
# 1. Criar sessão Spark
# ==================================================
spark = SparkSession.builder \
    .appName("Tarefa_IA_Regressao_Logistica") \
    .getOrCreate()

print("Sessão Spark iniciada com sucesso!")

# ==================================================
# 2. Leitura da base
# ==================================================
# Como o arquivo está em Excel, vamos ler com pandas
# e converter para DataFrame Spark
arquivo = r"C:\Users\Bruno Bartolomeu\Desktop\Discilpinas  Estácio - 2026\base_dados_ia.xlsx"

df_pandas = pd.read_excel(arquivo)
df = spark.createDataFrame(df_pandas)

print("\n=== Visualização inicial do DataFrame ===")
df.show(10, truncate=False)

print("\n=== Esquema do DataFrame ===")
df.printSchema()

print("\n=== Quantidade de linhas ===")
print(df.count())

# ==================================================
# 3. Tratamento da variável alvo
# ==================================================
# Converter resultado para numérico:
# Aprovado = 1
# Reprovado = 0
df = df.withColumn(
    "label",
    when(col("resultado") == "Aprovado", 1).otherwise(0)
)

print("\n=== Conferindo transformação da variável alvo ===")
df.select("nome", "resultado", "label").show(10, truncate=False)

# ==================================================
# 4. Seleção das variáveis de entrada
# ==================================================
features = ["nota1", "nota2", "frequencia", "horas_estudo"]

assembler = VectorAssembler(
    inputCols=features,
    outputCol="features"
)

df_modelo = assembler.transform(df).select("features", "label", "nome", "nota1", "nota2", "frequencia", "horas_estudo")

print("\n=== DataFrame pronto para modelagem ===")
df_modelo.show(10, truncate=False)

# ==================================================
# 5. Divisão treino e teste
# ==================================================
treino, teste = df_modelo.randomSplit([0.7, 0.3], seed=42)

print("\n=== Quantidade de registros ===")
print(f"Treino: {treino.count()}")
print(f"Teste: {teste.count()}")

# ==================================================
# 6. Treinamento do modelo
# ==================================================
lr = LogisticRegression(featuresCol="features", labelCol="label")
modelo = lr.fit(treino)

print("\nModelo treinado com sucesso!")

# ==================================================
# 7. Previsões
# ==================================================
previsoes = modelo.transform(teste)

print("\n=== Previsões do modelo ===")
previsoes.select(
    "nome",
    "nota1",
    "nota2",
    "frequencia",
    "horas_estudo",
    "label",
    "prediction",
    "probability"
).show(20, truncate=False)

# ==================================================
# 8. Avaliação
# ==================================================
avaliador_acuracia = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="accuracy"
)

acuracia = avaliador_acuracia.evaluate(previsoes)

print("\n=== Avaliação ===")
print(f"Acurácia: {acuracia:.4f}")

avaliador_auc = BinaryClassificationEvaluator(
    labelCol="label",
    rawPredictionCol="rawPrediction",
    metricName="areaUnderROC"
)

auc = avaliador_auc.evaluate(previsoes)
print(f"AUC: {auc:.4f}")

# ==================================================
# 9. Comparação entre real e previsto
# ==================================================
print("\n=== Comparação entre valor real e previsto ===")
resultado_final = previsoes.select(
    "nome",
    "nota1",
    "nota2",
    "frequencia",
    "horas_estudo",
    col("label").alias("real"),
    col("prediction").alias("previsto"),
    "probability"
)

resultado_final.show(20, truncate=False)

# ==================================================
# 10. Coeficientes do modelo
# ==================================================
print("\n=== Coeficientes da Regressão Logística ===")
coeficientes = modelo.coefficients
intercepto = modelo.intercept

for variavel, coef in zip(features, coeficientes):
    print(f"{variavel}: {coef:.4f}")

print(f"Intercepto: {intercepto:.4f}")

# ==================================================
# ==================================================
# 12. Encerrar Spark
# ==================================================
spark.stop()
print("\nSessão Spark encerrada.")