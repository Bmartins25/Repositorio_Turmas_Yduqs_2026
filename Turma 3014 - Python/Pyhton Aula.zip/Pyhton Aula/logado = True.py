logado = True

if logado:
    print("Usuário está logado")
else:
    print("Usuário não está logado")