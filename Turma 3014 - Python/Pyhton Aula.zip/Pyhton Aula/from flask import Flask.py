from flask import Flask

app = Flask(__name__)

@app.route("/")
def inicio():
    return """
    <html>
        <head>
            <title>Prática Web</title>
        </head>
        <body>
            <h1>Olá, alunos!</h1>
            <p>Bem-vindos à prática de Python Web.</p>
            
            <img src="https://4kwallpapers.com/images/wallpapers/python-programming-192x120-16102.jpg"
                 alt="Imagem exemplo">
        </body>
    </html>
    """

app.run(debug=True)