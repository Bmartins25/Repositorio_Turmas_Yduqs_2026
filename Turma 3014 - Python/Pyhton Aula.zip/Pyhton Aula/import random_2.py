import random

# =========================
# CONFIGURAÇÕES DO PROBLEMA
# =========================
TAMANHO_CROMOSSOMO = 10
TAMANHO_POPULACAO = 20
TAXA_MUTACAO = 0.1

# Critérios de parada
MAX_GERACOES = 50
APTIDAO_ALVO = 10          # melhor caso possível: 10 bits = todos 1
MAX_ESTAGNACAO = 8         # parar se não melhorar em 8 gerações seguidas


# =========================
# FUNÇÕES DO ALGORITMO
# =========================
def criar_individuo(tamanho):
    """Cria um indivíduo aleatório com genes 0 ou 1."""
    return [random.randint(0, 1) for _ in range(tamanho)]


def criar_populacao(tamanho_pop, tamanho_cromossomo):
    """Cria a população inicial."""
    return [criar_individuo(tamanho_cromossomo) for _ in range(tamanho_pop)]


def fitness(individuo):
    """
    Calcula a aptidão do indivíduo.
    Neste exemplo, quanto mais bits 1, melhor.
    """
    return sum(individuo)


def selecionar_pais(populacao):
    """
    Seleciona os 2 melhores indivíduos da população.
    Estratégia simples: elitismo.
    """
    populacao_ordenada = sorted(populacao, key=fitness, reverse=True)
    return populacao_ordenada[0], populacao_ordenada[1]


def crossover(pai1, pai2):
    """
    Realiza cruzamento de um ponto.
    Combina parte do pai1 com parte do pai2.
    """
    ponto_corte = random.randint(1, len(pai1) - 1)
    filho = pai1[:ponto_corte] + pai2[ponto_corte:]
    return filho


def mutacao(individuo, taxa_mutacao):
    """
    Aplica mutação gene a gene com uma probabilidade definida.
    """
    for i in range(len(individuo)):
        if random.random() < taxa_mutacao:
            individuo[i] = 1 - individuo[i]  # troca 0 por 1 ou 1 por 0
    return individuo


def melhor_individuo(populacao):
    """Retorna o melhor indivíduo da população."""
    return max(populacao, key=fitness)


# =========================
# ALGORITMO GENÉTICO
# =========================
def algoritmo_genetico():
    populacao = criar_populacao(TAMANHO_POPULACAO, TAMANHO_CROMOSSOMO)

    melhor_fitness_anterior = -1
    geracoes_sem_melhoria = 0

    for geracao in range(1, MAX_GERACOES + 1):

        # Avalia o melhor indivíduo da geração atual
        melhor = melhor_individuo(populacao)
        aptidao_melhor = fitness(melhor)

        print(f"Geração {geracao:02d} | Melhor indivíduo: {melhor} | Fitness: {aptidao_melhor}")

        # =======================================
        # CRITÉRIO 1: APTIDÃO SATISFATÓRIA
        # =======================================
        if aptidao_melhor >= APTIDAO_ALVO:
            print("\nParada por aptidão satisfatória.")
            print(f"Solução encontrada: {melhor}")
            return

        # =======================================
        # CRITÉRIO 2: ESTAGNAÇÃO
        # =======================================
        if aptidao_melhor > melhor_fitness_anterior:
            melhor_fitness_anterior = aptidao_melhor
            geracoes_sem_melhoria = 0
        else:
            geracoes_sem_melhoria += 1

        if geracoes_sem_melhoria >= MAX_ESTAGNACAO:
            print("\nParada por estagnação.")
            print(f"Melhor solução até aqui: {melhor}")
            return

        # =======================================
        # GERA NOVA POPULAÇÃO
        # =======================================
        nova_populacao = []

        # Mantém os 2 melhores (elitismo)
        pai1, pai2 = selecionar_pais(populacao)
        nova_populacao.append(pai1[:])
        nova_populacao.append(pai2[:])

        # Cria o restante da nova população
        while len(nova_populacao) < TAMANHO_POPULACAO:
            filho = crossover(pai1, pai2)
            filho = mutacao(filho, TAXA_MUTACAO)
            nova_populacao.append(filho)

        populacao = nova_populacao

    # =======================================
    # CRITÉRIO 3: NÚMERO MÁXIMO DE GERAÇÕES
    # =======================================
    melhor = melhor_individuo(populacao)
    print("\nParada por número máximo de gerações.")
    print(f"Melhor solução final: {melhor} | Fitness: {fitness(melhor)}")


# =========================
# EXECUÇÃO
# =========================
if __name__ == "__main__":
    algoritmo_genetico()