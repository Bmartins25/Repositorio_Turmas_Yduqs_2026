import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# =========================
# 1. Leitura da base
# =========================
# Ajuste o nome do arquivo se necessário
arquivo = r"C:\Users\Bruno Bartolomeu\Desktop\Discilpinas  Estácio - 2026\base_dados_ia.xlsx"

dados = pd.read_excel(arquivo)

print("=== Primeiras linhas da base ===")
print(dados.head())

print("\n=== Tipos de dados ===")
print(dados.dtypes)

print("\n=== Informações gerais ===")
print(dados.info())

# =========================
# 2. Preparação dos dados
# =========================
# Remover linhas com valores nulos, se existirem
dados = dados.dropna()

# Converter a variável alvo para formato numérico
# Aprovado = 1 | Reprovado = 0
dados["resultado"] = dados["resultado"].map({
    "Aprovado": 1,
    "Reprovado": 0
})

# Seleção das variáveis de entrada
X = dados[["nota1", "nota2", "frequencia", "horas_estudo"]]

# Variável alvo
y = dados["resultado"]

# =========================
# 3. Divisão treino e teste
# =========================
X_treino, X_teste, y_treino, y_teste = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# =========================
# 4. Criação e treino do modelo
# =========================
modelo = LogisticRegression(max_iter=1000)
modelo.fit(X_treino, y_treino)

# =========================
# 5. Previsões
# =========================
previsoes = modelo.predict(X_teste)
probabilidades = modelo.predict_proba(X_teste)

# =========================
# 6. Avaliação
# =========================
acuracia = accuracy_score(y_teste, previsoes)

print("\n=== Avaliação do Modelo ===")
print(f"Acurácia: {acuracia:.2f}")

print("\n=== Matriz de Confusão ===")
print(confusion_matrix(y_teste, previsoes))

print("\n=== Relatório de Classificação ===")
print(classification_report(y_teste, previsoes))

# =========================
# 7. Interpretação dos coeficientes
# =========================
coeficientes = pd.DataFrame({
    "Variavel": X.columns,
    "Coeficiente": modelo.coef_[0]
})

print("\n=== Influência das Variáveis ===")
print(coeficientes)

# =========================
# 8. Comparação entre real e previsto
# =========================
resultado_comparacao = X_teste.copy()
resultado_comparacao["Real"] = y_teste.values
resultado_comparacao["Previsto"] = previsoes
resultado_comparacao["Prob_Reprovado"] = probabilidades[:, 0]
resultado_comparacao["Prob_Aprovado"] = probabilidades[:, 1]

# Converter 0 e 1 para texto
resultado_comparacao["Real"] = resultado_comparacao["Real"].map({
    1: "Aprovado",
    0: "Reprovado"
})

resultado_comparacao["Previsto"] = resultado_comparacao["Previsto"].map({
    1: "Aprovado",
    0: "Reprovado"
})

print("\n=== Comparação entre valores reais e previstos ===")
print(resultado_comparacao.head(10))

