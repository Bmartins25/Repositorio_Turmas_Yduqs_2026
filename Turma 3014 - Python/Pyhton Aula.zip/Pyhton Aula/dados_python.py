import pandas as pd

df = pd.read_excel(r"C:\Users\Bruno Bartolomeu\Desktop\Discilpinas  Estácio - 2026\tarefa_python.xlsx")

print("\nBase de dados:\n")
print(df)

df["media"] = (df["Nota 1"] + df["Nota 2"]) / 2

df["situacao"] = df["media"].apply(lambda x: "Aprovado" if x >= 6 else "Reprovado")

print("\nResultado:\n")
print(df)