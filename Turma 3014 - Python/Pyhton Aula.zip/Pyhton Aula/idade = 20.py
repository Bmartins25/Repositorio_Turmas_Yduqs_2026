if (n := 10) > 5:
    print("Maior que 5:", n)