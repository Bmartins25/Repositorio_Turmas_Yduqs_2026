# Programa para calcular média de notas

# lista de notas
notas = [7.5, 8.0, 6.5, 9.0]

# variável acumuladora
soma = 0

# percorrendo a lista
for nota in notas:
    soma = soma + nota

# cálculo da média
media = soma / len(notas)

# resultado
print("A média das notas é:", media)

# verificação de aprovação
if media >= 7:
    print("Aluno aprovado")
else:
    print("Aluno reprovado")