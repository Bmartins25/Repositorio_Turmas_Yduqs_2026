Geração 01 | Melhor indivíduo: [1, 0, 1, 1, 1, 0, 1, 0, 1, 1] | Fitness: 7
Geração 02 | Melhor indivíduo: [1, 1, 1, 1, 1, 0, 1, 0, 1, 1] | Fitness: 8
Geração 03 | Melhor indivíduo: [1, 1, 1, 1, 1, 1, 1, 0, 1, 1] | Fitness: 9
Geração 04 | Melhor indivíduo: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1] | Fitness: 10

Parada por aptidão satisfatória.
Solução encontrada: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]