import networkx as nx
import matplotlib.pyplot as plt
from collections import deque
from matplotlib.patches import Patch

# -----------------------------------
# GRAFO BASE
# -----------------------------------
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': [],
    'F': []
}

# -----------------------------------
# FUNÇÃO BFS
# -----------------------------------
def bfs(graph, start):
    visited = []
    queue = deque([start])

    while queue:
        node = queue.popleft()
        if node not in visited:
            visited.append(node)
            queue.extend(graph[node])

    return visited

# -----------------------------------
# FUNÇÃO DFS
# -----------------------------------
def dfs(graph, start, visited=None):
    if visited is None:
        visited = []

    if start not in visited:
        visited.append(start)

        for neighbor in graph[start]:
            if neighbor not in visited:
                dfs(graph, neighbor, visited)

    return visited

# -----------------------------------
# EXECUÇÃO DOS ALGORITMOS
# -----------------------------------
bfs_order = bfs(graph, 'A')
dfs_order = dfs(graph, 'A')

# -----------------------------------
# CRIAÇÃO DO GRAFO NO NETWORKX
# -----------------------------------
G = nx.DiGraph()

for node in graph:
    if not graph[node]:
        G.add_node(node)
    for neighbor in graph[node]:
        G.add_edge(node, neighbor)

# -----------------------------------
# POSIÇÕES FIXAS DOS NÓS
# -----------------------------------
pos = {
    'A': (0, 2),
    'B': (-1, 1),
    'C': (1, 1),
    'D': (-1.5, 0),
    'E': (-0.5, 0),
    'F': (1, 0)
}

# -----------------------------------
# CONFIGURAÇÃO DA FIGURA
# -----------------------------------
fig, axes = plt.subplots(1, 2, figsize=(16, 8))
fig.suptitle("Comparação entre BFS e DFS", fontsize=16, fontweight='bold', y=0.97)

# -----------------------------------
# LEGENDA
# -----------------------------------
legend_bfs = [Patch(facecolor='lightblue', edgecolor='black', label='Nós do grafo')]
legend_dfs = [Patch(facecolor='lightgreen', edgecolor='black', label='Nós do grafo')]

# -----------------------------------
# GRÁFICO BFS
# -----------------------------------
nx.draw(
    G,
    pos,
    ax=axes[0],
    with_labels=True,
    node_color="lightblue",
    node_size=2200,
    font_size=14,
    font_weight='bold',
    arrows=True,
    arrowstyle='-|>',
    arrowsize=18,
    edge_color='black',
    width=1.5
)

axes[0].set_title(
    "Busca em Largura (BFS)\n"
    "Exploração por níveis\n"
    f"Ordem: {' → '.join(bfs_order)}",
    fontsize=13
)

axes[0].legend(
    handles=legend_bfs,
    loc='upper left',
    bbox_to_anchor=(-0.02, 1.02),
    fontsize=10,
    frameon=True
)

axes[0].text(
    0.5, -0.08,
    "BFS usa fila (queue).",
    transform=axes[0].transAxes,
    ha='center',
    fontsize=11
)

# -----------------------------------
# GRÁFICO DFS
# -----------------------------------
nx.draw(
    G,
    pos,
    ax=axes[1],
    with_labels=True,
    node_color="lightgreen",
    node_size=2200,
    font_size=14,
    font_weight='bold',
    arrows=True,
    arrowstyle='-|>',
    arrowsize=18,
    edge_color='black',
    width=1.5
)

axes[1].set_title(
    "Busca em Profundidade (DFS)\n"
    "Exploração até o final de cada ramo\n"
    f"Ordem: {' → '.join(dfs_order)}",
    fontsize=13
)

axes[1].legend(
    handles=legend_dfs,
    loc='upper right',
    bbox_to_anchor=(1.02, 1.02),
    fontsize=10,
    frameon=True
)

axes[1].text(
    0.5, -0.08,
    "DFS usa pilha/recursão.",
    transform=axes[1].transAxes,
    ha='center',
    fontsize=11
)

# -----------------------------------
# AJUSTES FINAIS
# -----------------------------------
for ax in axes:
    ax.axis('off')
    ax.set_xlim(-2.2, 1.7)
    ax.set_ylim(-0.4, 2.4)

plt.subplots_adjust(wspace=0.28, top=0.84, bottom=0.16)
plt.show()