texto = "Python"

# Isso dá erro:
# texto[0] = "J"

# Forma correta:
novo_texto = "J" + texto[1:]
print(novo_texto)